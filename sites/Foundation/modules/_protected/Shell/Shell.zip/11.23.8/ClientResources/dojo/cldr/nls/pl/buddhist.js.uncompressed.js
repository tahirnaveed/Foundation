define(
"dojo/cldr/nls/pl/buddhist", //begin v1.x content
{
	"dateFormatItem-yM": "MM.yyyy G",
	"dateFormatItem-yQ": "G y Q",
	"dateFormatItem-MMMEd": "E, d MMM",
	"dateFormatItem-hms": "hh:mm:ss a",
	"dateFormatItem-yQQQ": "G y QQQ",
	"dateFormatItem-MMdd": "d.MM",
	"days-standAlone-wide": [
		"niedziela",
		"poniedziałek",
		"wtorek",
		"środa",
		"czwartek",
		"piątek",
		"sobota"
	],
	"dateFormatItem-MMM": "LLL",
	"months-standAlone-narrow": [
		"s",
		"l",
		"m",
		"k",
		"m",
		"c",
		"l",
		"s",
		"w",
		"p",
		"l",
		"g"
	],
	"dateFormatItem-Gy": "y G",
	"quarters-standAlone-abbr": [
		"1 kw.",
		"2 kw.",
		"3 kw.",
		"4 kw."
	],
	"dateFormatItem-y": "y G",
	"months-standAlone-abbr": [
		"sty",
		"lut",
		"mar",
		"kwi",
		"maj",
		"cze",
		"lip",
		"sie",
		"wrz",
		"paź",
		"lis",
		"gru"
	],
	"dateFormatItem-Ed": "E, d",
	"dateFormatItem-yMMM": "LLL y G",
	"days-standAlone-narrow": [
		"N",
		"P",
		"W",
		"Ś",
		"C",
		"P",
		"S"
	],
	"dateFormatItem-yyyyMM": "MM.yyyy G",
	"dateFormatItem-yyyyMMMM": "LLLL y G",
	"dateFormat-long": "d MMMM, y G",
	"dateFormatItem-Hm": "HH:mm",
	"dateFormat-medium": "d MMM y G",
	"dateFormatItem-Hms": "HH:mm:ss",
	"dateFormatItem-yyMMM": "LLL y G",
	"dateFormatItem-yMd": "d.MM.yyyy G",
	"quarters-standAlone-wide": [
		"I kwartał",
		"II kwartał",
		"III kwartał",
		"IV kwartał"
	],
	"dateFormatItem-yMMMM": "LLLL y G",
	"dateFormatItem-ms": "mm:ss",
	"quarters-standAlone-narrow": [
		"K1",
		"K2",
		"K3",
		"K4"
	],
	"months-standAlone-wide": [
		"styczeń",
		"luty",
		"marzec",
		"kwiecień",
		"maj",
		"czerwiec",
		"lipiec",
		"sierpień",
		"wrzesień",
		"październik",
		"listopad",
		"grudzień"
	],
	"dateFormatItem-MMMd": "d MMM",
	"dateFormatItem-yyQ": "Q y G",
	"months-format-abbr": [
		"sty",
		"lut",
		"mar",
		"kwi",
		"maj",
		"cze",
		"lip",
		"sie",
		"wrz",
		"paź",
		"lis",
		"gru"
	],
	"dateFormatItem-MMMMd": "d MMMM",
	"quarters-format-abbr": [
		"K1",
		"K2",
		"K3",
		"K4"
	],
	"days-format-abbr": [
		"niedz.",
		"pon.",
		"wt.",
		"śr.",
		"czw.",
		"pt.",
		"sob."
	],
	"dateFormatItem-M": "L",
	"days-format-narrow": [
		"N",
		"P",
		"W",
		"Ś",
		"C",
		"P",
		"S"
	],
	"dateFormatItem-yMMMd": "d MMM y G",
	"dateFormatItem-MEd": "E, d.MM",
	"months-format-narrow": [
		"s",
		"l",
		"m",
		"k",
		"m",
		"c",
		"l",
		"s",
		"w",
		"p",
		"l",
		"g"
	],
	"days-standAlone-short": [
		"niedz.",
		"pon.",
		"wt.",
		"śr.",
		"czw.",
		"pt.",
		"sob."
	],
	"dateFormatItem-hm": "hh:mm a",
	"days-standAlone-abbr": [
		"niedz.",
		"pon.",
		"wt.",
		"śr.",
		"czw.",
		"pt.",
		"sob."
	],
	"dateFormat-short": "dd.MM.yyyy G",
	"dateFormatItem-yMMMEd": "E, d MMM y G",
	"dateFormat-full": "EEEE, d MMMM, y G",
	"dateFormatItem-Md": "d.MM",
	"dateFormatItem-yMEd": "E, d.MM.yyyy G",
	"months-format-wide": [
		"stycznia",
		"lutego",
		"marca",
		"kwietnia",
		"maja",
		"czerwca",
		"lipca",
		"sierpnia",
		"września",
		"października",
		"listopada",
		"grudnia"
	],
	"days-format-short": [
		"niedz.",
		"pon.",
		"wt.",
		"śr.",
		"czw.",
		"pt.",
		"sob."
	],
	"dateFormatItem-d": "d",
	"quarters-format-wide": [
		"I kwartał",
		"II kwartał",
		"III kwartał",
		"IV kwartał"
	],
	"days-format-wide": [
		"niedziela",
		"poniedziałek",
		"wtorek",
		"środa",
		"czwartek",
		"piątek",
		"sobota"
	],
	"dateFormatItem-h": "hh a"
}
//end v1.x content
);